# SignalLink Android Starter

Native Android starter project for Android 13+ with Bluetooth status/permission checks, Wi-Fi settings access, and network diagnostics. Peer-to-peer messaging is not implemented yet.

## Build

The included GitHub Actions workflow builds a debug APK when you push to `main` or manually run the workflow. The artifact is named `SignalLink-Android-APK` and contains `app-debug.apk`.

## Security and feature limits

The app does not bypass Wi-Fi protections or extract arbitrary saved passwords. Bluetooth discovery, device-to-device transport, and message delivery require further implementation and real-device testing.
