SIGNALLINK — ANDROID PHONE CLOUD BUILD KIT

This repository-ready folder contains the native Android starter app and a GitHub Actions workflow. It does not contain a prebuilt APK; GitHub must compile it first.

BUILD USING ONLY YOUR ANDROID PHONE
1. Extract this ZIP using your Android file manager.
2. Open https://github.com in Chrome and sign in.
3. Create a new repository named SignalLink-Android. Public is simplest for this starter; do not add secrets or personal information.
4. In the repository, use Add file > Upload files. Upload the CONTENTS of this folder (not the outer folder itself), including the hidden .github folder and its workflows/android-build.yml file. If the mobile website hides dot-folders, switch Chrome to Desktop site or use GitHub's web editor to create .github/workflows/android-build.yml and paste the workflow from this folder.
5. Commit the files to the main branch.
6. Open the repository's Actions tab, select Build SignalLink APK, tap Run workflow if it has not started automatically, and run it on main.
7. Open the completed workflow run. Under Artifacts, download SignalLink-Android-APK. Extract that downloaded ZIP to get app-debug.apk.
8. Tap app-debug.apk to install. If Android asks, allow Chrome or your file manager to install unknown apps. Only install APKs you built and trust.

WHAT THIS STARTER DOES
- Checks Bluetooth hardware/status and requests nearby Bluetooth permissions.
- Opens Android Wi-Fi settings.
- Checks whether Wi-Fi/mobile network connectivity is active.
- Gives safe Wi-Fi recovery guidance.

LIMITATIONS
- This is a native Android starter app, not a complete peer-to-peer messenger.
- It does not yet discover peers, pair devices automatically, or deliver chat messages between phones.
- It cannot bypass Wi-Fi security or reveal arbitrary saved passwords.
- The build workflow has not been run from this account because that requires your GitHub repository/account. A successful green workflow run and downloadable artifact are the proof of a compiled APK.
