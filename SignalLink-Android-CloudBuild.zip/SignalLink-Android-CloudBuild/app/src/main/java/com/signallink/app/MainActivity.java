package com.signallink.app;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private LinearLayout content;
    private TextView status;
    private static final int REQ_BT = 412;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(36, 40, 36, 36);
        content.setBackgroundColor(0xFFF4F7FB); scroll.addView(content); setContentView(scroll);
        TextView title = new TextView(this); title.setText("SignalLink"); title.setTextSize(32); title.setTextColor(0xFF102238); title.setGravity(Gravity.CENTER); title.setTypeface(null, 1); content.addView(title);
        TextView subtitle = new TextView(this); subtitle.setText("Bluetooth • Wi-Fi • Device connectivity"); subtitle.setTextSize(14); subtitle.setGravity(Gravity.CENTER); subtitle.setPadding(0, 8, 0, 24); content.addView(subtitle);
        status = new TextView(this); status.setTextSize(16); status.setTextColor(0xFF24364B); status.setPadding(18, 18, 18, 18); status.setBackgroundColor(0xFFFFFFFF); content.addView(status);
        addButton("Check Bluetooth", v -> checkBluetooth());
        addButton("Request Bluetooth permission", v -> requestBluetooth());
        addButton("Open Wi-Fi settings", v -> startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)));
        addButton("Check network connection", v -> checkNetwork());
        addButton("About Wi-Fi password recovery", v -> show("Android does not let ordinary apps reveal arbitrary Wi-Fi passwords. Check saved networks in your phone's Wi-Fi settings, or use the router label/admin page for a network you own or manage."));
        checkNetwork();
    }

    private void addButton(String label, View.OnClickListener listener) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(15); b.setPadding(8, 12, 8, 12);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = 14; content.addView(b, lp); b.setOnClickListener(listener);
    }
    private void show(String message) { status.setText(message); }
    private void checkBluetooth() {
        BluetoothManager manager = (BluetoothManager)getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
        if (adapter == null) { show("This device does not report Bluetooth support."); return; }
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestBluetooth(); show("Bluetooth permission is needed to read Bluetooth status."); return;
        }
        show("Bluetooth hardware is available. Bluetooth is " + (adapter.isEnabled() ? "ON." : "OFF. Open Quick Settings to turn it on."));
    }
    private void requestBluetooth() {
        if (Build.VERSION.SDK_INT >= 31) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT);
        } else checkBluetooth();
    }
    private void checkNetwork() {
        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        Network n = cm == null ? null : cm.getActiveNetwork();
        NetworkCapabilities caps = n == null || cm == null ? null : cm.getNetworkCapabilities(n);
        if (caps == null) { show("No active network connection detected. Check Wi-Fi or mobile data."); return; }
        String kind = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ? "Wi-Fi" : caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ? "mobile data" : caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ? "Ethernet" : "another network";
        show("Network connection detected: " + kind + ". This checks connectivity status only; it does not reveal network passwords.");
    }
}
